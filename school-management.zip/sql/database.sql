-- SQL Dump for School Management System
CREATE TABLE students (id INT, name VARCHAR(100));